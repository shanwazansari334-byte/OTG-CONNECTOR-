package com.shanboiz78.otgconnector

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var statusText: TextView
    private lateinit var devicesText: TextView
    private lateinit var scanButton: Button
    private lateinit var requestButton: Button
    private var selectedDevice: UsbDevice? = null

    private val permissionAction = "com.shanboiz78.otgconnector.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                permissionAction -> {
                    val device = getUsbDevice(intent)
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    statusText.text = if (granted && device != null) {
                        "Permission granted for ${device.deviceName}. This app can now access the USB device if it supports a usable USB interface."
                    } else {
                        "USB permission was not granted. Try again or check the device/adapter."
                    }
                    refreshDevices()
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    statusText.text = "USB device attached. Checking device…"
                    refreshDevices()
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    statusText.text = "USB device disconnected."
                    selectedDevice = null
                    refreshDevices()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun getUsbDevice(intent: Intent): UsbDevice? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()

        val filter = IntentFilter().apply {
            addAction(permissionAction)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(usbReceiver, filter)
        }
        refreshDevices()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "OTG CONNECTOR"
            textSize = 27f
            setTextColor(0xFF55E6A5.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "USB support checker & device permission"
            textSize = 14f
            setTextColor(0xFFE6EDF3.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        statusText = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF263746.toInt())
            text = "Checking USB host support…"
        }
        scanButton = Button(this).apply {
            text = "SCAN USB DEVICES"
            setOnClickListener { refreshDevices() }
        }
        requestButton = Button(this).apply {
            text = "REQUEST USB PERMISSION"
            isEnabled = false
            setOnClickListener { requestSelectedDevicePermission() }
        }
        devicesText = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFE6EDF3.toInt())
            setPadding(4, 12, 4, 12)
        }
        val note = TextView(this).apply {
            text = "Important: This app cannot add missing OTG hardware or force-enable a system OTG switch. USB-C/USB OTG adapter, phone host support, power and device compatibility are required. USB microphones may need a compatible USB audio driver/app."
            textSize = 13f
            setTextColor(0xFFB8C7D1.toInt())
            setPadding(4, 18, 4, 4)
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(statusText, matchWrap())
        root.addView(scanButton, matchWrap())
        root.addView(requestButton, matchWrap())
        root.addView(devicesText, matchWrap())
        root.addView(note, matchWrap())

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 10
        }

    private fun refreshDevices() {
        val hasHostFeature = packageManager.hasSystemFeature("android.hardware.usb.host")
        val deviceMap = usbManager.deviceList
        selectedDevice = deviceMap.values.firstOrNull()

        statusText.text = when {
            !hasHostFeature -> "This phone does not report USB host (OTG) support. An app cannot add this hardware feature."
            deviceMap.isEmpty() -> "USB host feature is reported. No USB device detected. Connect an OTG adapter and device, then scan again."
            else -> "USB host feature is reported. Found ${deviceMap.size} USB device(s). Choose permission for a detected device below."
        }

        if (deviceMap.isEmpty()) {
            devicesText.text = "Detected devices: none"
            requestButton.isEnabled = false
            return
        }

        val lines = deviceMap.values.mapIndexed { index, device ->
            "${index + 1}. ${device.deviceName}\n   Vendor ID: ${device.vendorId} | Product ID: ${device.productId}\n   USB class: ${device.deviceClass} | Interfaces: ${device.interfaceCount}"
        }
        devicesText.text = "Detected devices:\n\n" + lines.joinToString("\n\n")
        requestButton.isEnabled = selectedDevice != null
        requestButton.text = if (selectedDevice == null) "NO DEVICE SELECTED" else "REQUEST PERMISSION FOR FIRST DEVICE"
    }

    private fun requestSelectedDevicePermission() {
        val device = selectedDevice
        if (device == null) {
            statusText.text = "No USB device detected. Connect a device and scan again."
            return
        }
        if (usbManager.hasPermission(device)) {
            statusText.text = "Permission already granted for ${device.deviceName}. Device-specific support still depends on its USB interface and compatible app/driver."
            return
        }

        val intent = Intent(permissionAction).setPackage(packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val permissionIntent = PendingIntent.getBroadcast(this, 0, intent, flags)
        usbManager.requestPermission(device, permissionIntent)
        statusText.text = "Permission request sent. Accept the Android USB permission dialog if it appears."
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(usbReceiver) } catch (_: IllegalArgumentException) { }
    }
}
