plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shanboiz78.otgconnector"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shanboiz78.otgconnector"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
