# OTG CONNECTOR — Android source project

## Build an APK using GitHub on your phone
1. Create a GitHub repository named `OTG-CONNECTOR`.
2. Upload all project files and folders from this ZIP, including `.github/workflows/android.yml`.
3. Commit the upload to the `main` branch.
4. Open the repository's **Actions** tab and choose **Build OTG CONNECTOR APK**.
5. Tap **Run workflow** if needed. Wait for a successful run.
6. Open the run and download the `OTG-CONNECTOR-debug-apk` artifact. Extract that downloaded ZIP to get `app-debug.apk`.
7. Tap the APK to install. Only allow installation if you trust the repository and build you triggered.

## Limits
This app checks USB host support, lists detected USB devices, and requests USB permission. It cannot add missing OTG hardware or force-enable a system OTG switch. Phone host support, adapter, power and compatible device/app support are required. USB microphones may need a compatible recording app.

The source has not been compiled or device-tested in this environment.
